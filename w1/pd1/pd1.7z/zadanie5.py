A = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9}

result = set()
result.add(frozenset())

tmp = set()
for x in A:
    tmp.add(x)
    result.add(frozenset(tmp))

assert frozenset((0, 1, 2, 3, 4, 5, 6, 7, 8, 9)) in result