result = None

result = [[x] for x in range(0,100,2)]

assert result[1] == [2]